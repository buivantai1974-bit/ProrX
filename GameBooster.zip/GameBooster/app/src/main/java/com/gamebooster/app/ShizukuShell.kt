package com.gamebooster.app

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.withContext
import rikka.shizuku.Shizuku
import java.lang.reflect.Method

/**
 * Chạy lệnh shell với quyền ADB (shell) thông qua Shizuku.
 * Shizuku.newProcess() là hàm private từ bản 13.x nên gọi qua reflection.
 */
object ShizukuShell {

    data class Result(val exitCode: Int, val output: String, val error: String) {
        val isSuccess: Boolean get() = exitCode == 0
    }

    private val newProcessMethod: Method by lazy {
        Shizuku::class.java.getDeclaredMethod(
            "newProcess",
            Array<String>::class.java,
            Array<String>::class.java,
            String::class.java
        ).apply { isAccessible = true }
    }

    /** Chạy trên luồng IO, đọc đồng thời stdout và stderr để không bị treo. */
    suspend fun exec(command: String): Result = withContext(Dispatchers.IO) {
        var process: Process? = null
        try {
            val p = newProcessMethod.invoke(null, arrayOf("sh", "-c", command), null, null) as Process
            process = p
            coroutineScope {
                val stdout = async { p.inputStream.bufferedReader().use { it.readText() } }
                val stderr = async { p.errorStream.bufferedReader().use { it.readText() } }
                val code = p.waitFor()
                Result(code, stdout.await().trim(), stderr.await().trim())
            }
        } catch (e: Exception) {
            val msg = e.cause?.message ?: e.message ?: e.toString()
            Result(-1, "", msg)
        } finally {
            try {
                process?.destroy()
            } catch (ignored: Exception) {
                // không cần xử lý thêm
            }
        }
    }
}
