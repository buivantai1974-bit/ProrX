package com.gamebooster.app

import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Bundle
import android.widget.Button
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.launch
import rikka.shizuku.Shizuku
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : AppCompatActivity() {

    companion object {
        private const val REQUEST_CODE_SHIZUKU = 1001
    }

    private lateinit var tvStatus: TextView
    private lateinit var btnOptimize: Button
    private lateinit var tvLog: TextView
    private lateinit var scrollLog: ScrollView

    private var isRunning = false

    // --- Listeners vòng đời Shizuku ---
    private val binderReceivedListener = Shizuku.OnBinderReceivedListener {
        runOnUiThread {
            appendLog("Shizuku đã chạy (binder nhận được).")
            updateStatus()
        }
    }

    private val binderDeadListener = Shizuku.OnBinderDeadListener {
        runOnUiThread {
            appendLog("Shizuku đã dừng (binder mất kết nối).")
            updateStatus()
        }
    }

    private val permissionResultListener =
        Shizuku.OnRequestPermissionResultListener { requestCode, grantResult ->
            if (requestCode != REQUEST_CODE_SHIZUKU) return@OnRequestPermissionResultListener
            runOnUiThread {
                if (grantResult == PackageManager.PERMISSION_GRANTED) {
                    appendLog("✅ Đã được cấp quyền Shizuku.")
                    Toast.makeText(this, "Đã cấp quyền Shizuku", Toast.LENGTH_SHORT).show()
                } else {
                    appendLog("❌ Quyền Shizuku bị từ chối.")
                    Toast.makeText(this, "Quyền Shizuku bị từ chối", Toast.LENGTH_SHORT).show()
                }
                updateStatus()
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        tvStatus = findViewById(R.id.tvStatus)
        btnOptimize = findViewById(R.id.btnOptimize)
        tvLog = findViewById(R.id.tvLog)
        scrollLog = findViewById(R.id.scrollLog)

        Shizuku.addBinderReceivedListenerSticky(binderReceivedListener)
        Shizuku.addBinderDeadListener(binderDeadListener)
        Shizuku.addRequestPermissionResultListener(permissionResultListener)

        btnOptimize.setOnClickListener { onOptimizeClicked() }

        appendLog("Chào mừng! Hãy bật Shizuku và cấp quyền cho ứng dụng.")
        updateStatus()
    }

    override fun onResume() {
        super.onResume()
        updateStatus()
    }

    override fun onDestroy() {
        super.onDestroy()
        Shizuku.removeBinderReceivedListener(binderReceivedListener)
        Shizuku.removeBinderDeadListener(binderDeadListener)
        Shizuku.removeRequestPermissionResultListener(permissionResultListener)
    }

    // --- Quản lý quyền ---

    private fun isShizukuRunning(): Boolean = Shizuku.pingBinder()

    private fun hasShizukuPermission(): Boolean {
        return try {
            isShizukuRunning() &&
                !Shizuku.isPreV11() &&
                Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
        } catch (e: Exception) {
            false
        }
    }

    private fun requestShizukuPermission() {
        try {
            if (Shizuku.isPreV11()) {
                Toast.makeText(this, "Phiên bản Shizuku quá cũ, hãy cập nhật.", Toast.LENGTH_LONG).show()
                return
            }
            if (Shizuku.shouldShowRequestPermissionRationale()) {
                appendLog("⚠️ Bạn đã chọn \"Từ chối và không hỏi lại\". Hãy cấp quyền trong app Shizuku.")
                Toast.makeText(this, "Hãy cấp quyền trong ứng dụng Shizuku", Toast.LENGTH_LONG).show()
                return
            }
            appendLog("Đang yêu cầu quyền Shizuku...")
            Shizuku.requestPermission(REQUEST_CODE_SHIZUKU)
        } catch (e: Exception) {
            appendLog("❌ Lỗi khi xin quyền: ${e.message}")
        }
    }

    private fun updateStatus() {
        val running = isShizukuRunning()
        val granted = hasShizukuPermission()
        when {
            running && granted -> {
                tvStatus.text = "● Đã kết nối"
                tvStatus.setTextColor(Color.parseColor("#00FF9C"))
            }
            running -> {
                tvStatus.text = "● Chưa kết nối (chưa cấp quyền)"
                tvStatus.setTextColor(Color.parseColor("#FFB800"))
            }
            else -> {
                tvStatus.text = "● Chưa kết nối (Shizuku chưa chạy)"
                tvStatus.setTextColor(Color.parseColor("#FF3B5C"))
            }
        }
    }

    // --- Xử lý nút bấm ---

    private fun onOptimizeClicked() {
        if (isRunning) return

        if (!isShizukuRunning()) {
            appendLog("❌ Shizuku chưa chạy. Hãy mở app Shizuku và khởi động dịch vụ.")
            Toast.makeText(this, "Shizuku chưa chạy", Toast.LENGTH_SHORT).show()
            updateStatus()
            return
        }

        if (!hasShizukuPermission()) {
            requestShizukuPermission()
            return
        }

        isRunning = true
        btnOptimize.isEnabled = false
        btnOptimize.text = "⏳ Đang tối ưu..."

        lifecycleScope.launch {
            try {
                Optimizer.runAll { message -> runOnUiThread { appendLog(message) } }
            } catch (e: Exception) {
                appendLog("❌ Lỗi không mong muốn: ${e.message}")
            } finally {
                isRunning = false
                btnOptimize.isEnabled = true
                btnOptimize.text = "🚀 Tối Ưu Hóa & Vào Game"
            }
        }
    }

    // --- Log ---

    private fun appendLog(message: String) {
        val time = SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date())
        tvLog.append("[$time] $message\n")
        scrollLog.post { scrollLog.fullScroll(ScrollView.FOCUS_DOWN) }
    }
}
