package com.gamebooster.app

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.io.File

/** Các tính năng tối ưu hiệu năng. Mỗi hàm là suspend, chạy ngoài luồng UI. */
object Optimizer {

    private val SELF_PACKAGE = "com.gamebooster.app"

    /** Từ khóa các app quan trọng không bao giờ bị Force Stop. */
    private val PROTECTED_KEYWORDS = listOf(
        "moe.shizuku", "launcher", "inputmethod", "keyboard", "dialer", "telecom",
        "systemui", "com.google.android.gms", "com.google.android.gsf", "com.android.",
        "messaging", "contacts", "com.samsung.android", "com.miui", "com.oneplus",
        "com.oppo", "com.vivo", "com.huawei"
    )

    /** 1. Buộc tối ưu hóa (Dexopt). */
    suspend fun runDexopt(log: (String) -> Unit): Boolean {
        log("⏳ Đang chạy Dexopt (có thể mất vài chục giây)...")
        val r = ShizukuShell.exec("cmd package bg-dexopt-job")
        return if (r.isSuccess) {
            log("✅ Dexopt hoàn tất. ${r.output.take(200)}")
            true
        } else {
            log("❌ Dexopt lỗi (mã ${r.exitCode}): ${r.error.ifBlank { r.output }.take(200)}")
            false
        }
    }

    /** 2. Dọn bộ nhớ đệm sâu. */
    suspend fun runDeepCacheClean(log: (String) -> Unit): Boolean {
        log("⏳ Đang dọn bộ nhớ đệm sâu (pm trim-caches 999G)...")
        val r = ShizukuShell.exec("pm trim-caches 999G")
        return if (r.isSuccess) {
            log("✅ Đã dọn cache hệ thống. ${r.output.take(200)}")
            true
        } else {
            log("❌ Dọn cache lỗi (mã ${r.exitCode}): ${r.error.ifBlank { r.output }.take(200)}")
            false
        }
    }

    /** 3. Giải phóng RAM: Force Stop các app bên thứ ba không quan trọng. */
    suspend fun runFreeRam(log: (String) -> Unit): Boolean {
        log("⏳ Đang quét ứng dụng nền...")
        val before = readAvailableMemMb()

        val list = ShizukuShell.exec("pm list packages -3")
        if (!list.isSuccess) {
            log("❌ Không lấy được danh sách app (mã ${list.exitCode}): ${list.error.take(200)}")
            return false
        }

        val safe = HashSet<String>()
        safe.add(SELF_PACKAGE)
        safe.addAll(resolveHomePackage())
        safe.addAll(resolveImePackage())

        val targets = list.output.lines()
            .map { it.trim().removePrefix("package:") }
            .filter { it.isNotEmpty() }
            .filter { pkg -> pkg !in safe && PROTECTED_KEYWORDS.none { pkg.contains(it, ignoreCase = true) } }

        log("🔎 Tìm thấy ${targets.size} app có thể dừng.")
        var stopped = 0
        for (pkg in targets) {
            val r = ShizukuShell.exec("am force-stop $pkg")
            if (r.isSuccess) {
                stopped++
                log("   ⛔ Đã dừng: $pkg")
            } else {
                log("   ⚠️ Bỏ qua $pkg: ${r.error.take(100)}")
            }
        }

        delay(1500)
        val after = readAvailableMemMb()
        val freed = if (before >= 0 && after >= 0) maxOf(0L, after - before) else 0L
        log("✅ Đã dừng $stopped app. Đã giải phóng ~${freed}MB RAM (RAM trống: ${after}MB).")
        return true
    }

    private suspend fun resolveHomePackage(): Set<String> {
        val r = ShizukuShell.exec(
            "cmd package resolve-activity --brief -a android.intent.action.MAIN -c android.intent.category.HOME"
        )
        val last = r.output.lines().lastOrNull { it.contains("/") } ?: return emptySet()
        return setOf(last.trim().substringBefore("/"))
    }

    private suspend fun resolveImePackage(): Set<String> {
        val r = ShizukuShell.exec("settings get secure default_input_method")
        val v = r.output.trim()
        if (!v.contains("/")) return emptySet()
        return setOf(v.substringBefore("/"))
    }

    /** Đọc MemAvailable (MB) từ /proc/meminfo, trả -1 nếu lỗi. */
    suspend fun readAvailableMemMb(): Long = withContext(Dispatchers.IO) {
        try {
            File("/proc/meminfo").useLines { lines ->
                val line = lines.firstOrNull { it.startsWith("MemAvailable:") }
                val kb = line?.filter { it.isDigit() }?.toLongOrNull()
                if (kb != null) kb / 1024 else -1L
            }
        } catch (e: Exception) {
            -1L
        }
    }

    /** Chạy toàn bộ chuỗi tối ưu. */
    suspend fun runAll(log: (String) -> Unit) {
        log("🚀 Bắt đầu chuỗi tối ưu hóa...")
        runDexopt(log)
        runDeepCacheClean(log)
        runFreeRam(log)
        log("🎮 Hoàn tất! Sẵn sàng vào game.")
    }
}
